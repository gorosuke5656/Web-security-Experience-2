<?php
  require_once("function.php");
  session_start();
  header("Content-type: text/html; charset=utf-8");

?> <!doctype html> <html lang="ja"> <body>
  <h1>ログイン</h1>
  <?php
    if ($_SESSION["error_status"] == 1) {
      echo "<h2
style='color:red'>IDまたはパスワードが異なります。</h2>";
    }
    if ($_SESSION["logout_status"] == 1) {
      echo "<h2>ログアウトしました。</h2>";
    }
    //ステータス情報のリセット
    $_SESSION["error_status"] = 0;
    $_SESSION["logout_status"] = 0;
  ?>
  <form action="login_check.php" method="post">
  <table border="0">
    <tr>
      <td>ID </td>
      <td><input type="text" name="id"></td>
    </tr>
    <tr>
    <td>
      Password
    </td>
    <td>
      <input type="password" name="password">
    </td>
    </tr>
   </table>

    <input type="submit" value="ログイン">
    <input type="reset" value="リセット">
  </form>

</body>
</html>

