<?php
  session_start();
  header("Content-type: text/html; charset=utf-8");
 ?> <!doctype html> <html lang="ja">
   <body>
    <h1>罠ページ</h1>
      <a href="https://gorosuke-genki-inu-1.paiza-user-free.cloud/logout.php">強制ログアウト</a>
   </body>
</html>
