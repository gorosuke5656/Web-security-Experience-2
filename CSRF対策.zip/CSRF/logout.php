<?php
  session_start();
  header("Content-type: text/html; charset=utf-8");
  if(preg_match('#\Ahttps?:\/\/gorosuke-genki-inu-1.paiza-user-free.cloud/welcome.php#', $_SERVER['HTTP_REFERER']) !== 1){
    die('正規の画面から実行してください');
  }
  //セッション破棄
  $_SESSION = array();
  session_destroy();
  //ログアウト情報更新
  session_start();
  $_SESSION["logout_status"] = 1;
   //リダイレクト
  header("HTTP/1.1 301 Moved Permanently");
  header("Location: login.php");

