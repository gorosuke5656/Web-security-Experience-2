<?php
  require_once("function.php");
  session_start();
  header("Content-type: text/html; charset=utf-8");
  //エラー情報リセット
  $_SESSION["error_status"] = 0; ?> <!doctype html> <html lang="ja">
<body>
  <h1>ようこそ</h1>
    <a href="trap.php">罠ページへ移動</a>&nbsp;
    <a href="logout.php">ログアウト</a>
</body>
</html>

